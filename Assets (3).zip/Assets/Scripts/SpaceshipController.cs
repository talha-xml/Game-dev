using UnityEngine;

public class SpaceshipController : MonoBehaviour
{
    public float moveSpeed = 5f; // Speed for left/right movement
    public float forwardBackwardSpeed = 2f; // Slower speed for forward/backward
    public float tiltAmount = 15f; // Tilt angle for left/right movement

    private float horizontalInput;
    private float verticalInput;

    void Update()
    {
        // Get input for horizontal and vertical movement
        horizontalInput = Input.GetAxis("Horizontal"); // Left/Right (A/D or Arrow Keys)
        verticalInput = Input.GetAxis("Vertical"); // Forward/Backward (W/S or Arrow Keys)

        // Move the spaceship horizontally (left/right)
        if (horizontalInput != 0)
        {
            transform.Translate(Vector3.right * horizontalInput * moveSpeed * Time.deltaTime);

            // Apply tilt based on horizontal input
            float tilt = -horizontalInput * tiltAmount;
            transform.rotation = Quaternion.Euler(0f, 0f, tilt);
        }

        // Move the spaceship vertically (forward/backward), but only if vertical input is active
        if (verticalInput != 0)
        {
            transform.Translate(Vector3.up * verticalInput * forwardBackwardSpeed * Time.deltaTime);
        }
    }
}
