using UnityEngine;
using UnityEngine.SceneManagement;  // Required for scene management
using UnityEngine.UI;  // Required for UI buttons

public class MainMenu : MonoBehaviour
{
    // Assign these buttons in the Inspector
    public Button playButton;
    public Button exitButton;
    public Button instructionButton;
    public Button backButton;  // New back button

    void Start()
    {
        // Add listeners to buttons
        playButton.onClick.AddListener(StartGame);
        exitButton.onClick.AddListener(ExitGame);
        instructionButton.onClick.AddListener(ShowInstructions);
        backButton.onClick.AddListener(BackToMainMenu);  // Add listener for back button
    }

    // Start the game (Load a new scene, for example, "GameScene")
    public void StartGame()
    {
        // Replace "Level 1" with your actual game scene name
        SceneManager.LoadScene("Level 1");
    }

    // Exit the game
    public void ExitGame()
    {
        #if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false; // Stop play mode in the editor
        #else
        Application.Quit(); // Quit the application
        #endif
    }

    // Instruction button click behavior (You can replace this with any action you want)
    public void ShowInstructions()
    {
        // This function can be customized to do something if needed
        // Currently, it behaves like any other button
        SceneManager.LoadScene("Instructions");
    
    }

    // Back button click behavior to return to the main menu
    public void BackToMainMenu()
    {
        // Replace "MainMenu" with the actual name of your main menu scene
        SceneManager.LoadScene("Main Menu");
    }
}
