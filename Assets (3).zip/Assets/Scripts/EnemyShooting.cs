using UnityEngine;

public class EnemyShooting : MonoBehaviour
{
    public GameObject bulletPrefab;        // Bullet prefab
    public Transform shootingPoint3;       // First shooting point
    public Transform shootingPoint4;       // Second shooting point
    public float shootingInterval = 1.0f;  // Time interval between shots
    public float bulletSpeed = 5f;         // Speed of the bullet

    void Start()
    {
        InvokeRepeating(nameof(Shoot), 0f, shootingInterval); // Start shooting bullets
    }

    void Shoot()
    {
        if (bulletPrefab != null)
        {
            if (shootingPoint3 != null) ShootFromPoint(shootingPoint3);
            if (shootingPoint4 != null) ShootFromPoint(shootingPoint4);
        }
    }

    void ShootFromPoint(Transform shootingPoint)
    {
        GameObject bullet = Instantiate(bulletPrefab, shootingPoint.position, shootingPoint.rotation);
        Rigidbody2D bulletRb = bullet.GetComponent<Rigidbody2D>();
        if (bulletRb != null)
        {
            bulletRb.velocity = Vector2.down * bulletSpeed; // Move the bullet downward
        }
    }

    // This function will be triggered when the enemy collides with a bullet
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("PlayerBullet"))  // Check if the other object is a bullet
        {
            // Destroy this enemy when it collides with a bullet
            Destroy(gameObject);
        }
    }
}
