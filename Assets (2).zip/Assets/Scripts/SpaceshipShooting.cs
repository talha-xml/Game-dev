using UnityEngine;

public class SpaceshipShooting : MonoBehaviour
{
    public GameObject laserPrefab;         // Laser prefab reference
    public float laserSpeed = 10f;         // Speed of the laser
    public Transform shootingPoint1;       // First shooting point (for first gun)
    public Transform shootingPoint2;       // Second shooting point (for second gun)

    void Update()
    {
        // Fire laser from both shooting points when Spacebar is pressed
        if (Input.GetKeyDown(KeyCode.Space))
        {
            FireLaser(shootingPoint1);   // Fire from first gun
            FireLaser(shootingPoint2);   // Fire from second gun
        }
    }

    void FireLaser(Transform shootingPoint)
    {
        // Instantiate the laser at the shooting point and in the spaceship's rotation
        GameObject laser = Instantiate(laserPrefab, shootingPoint.position, shootingPoint.rotation);

        // Get the Rigidbody2D component attached to the laser
        Rigidbody2D rb = laser.GetComponent<Rigidbody2D>();

        // If Rigidbody2D is found, apply the velocity to move it forward
        if (rb != null)
        {
            rb.velocity = transform.up * laserSpeed;  // Move the laser forward
        }
    }
}
