using UnityEngine;

public class EnemyShooting : MonoBehaviour
{
    public GameObject bulletPrefab;        // Player laser prefab to be used by enemy
    public Transform shootingPoint3;       // First shooting point (e.g., left minigun)
    public Transform shootingPoint4;       // Second shooting point (e.g., right minigun)
    public float shootingInterval = 1.0f;  // Time interval between shots
    public float bulletSpeed = 5f;         // Speed of the bullet

    void Start()
    {
        // Start shooting bullets from both points at the specified interval
        InvokeRepeating(nameof(Shoot), 0f, shootingInterval);
    }

    void Shoot()
    {
        // Check if the bullet prefab and shooting points are assigned
        if (bulletPrefab != null)
        {
            if (shootingPoint3 != null) ShootFromPoint(shootingPoint3);
            if (shootingPoint4 != null) ShootFromPoint(shootingPoint4);
        }
    }

    void ShootFromPoint(Transform shootingPoint)
    {
        GameObject bullet = Instantiate(bulletPrefab, shootingPoint.position, shootingPoint.rotation);
        Rigidbody2D bulletRb = bullet.GetComponent<Rigidbody2D>();
        if (bulletRb != null)
        {
            bulletRb.velocity = Vector2.down * bulletSpeed; // Move the bullet downward
        }
    }

    // Destroy enemy when hit by the player's laser
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Check if the collision is with a player's bullet
        if (collision.CompareTag("PlayerBullet")) // Ensure the player's bullet has the tag "PlayerBullet"
        {
            Destroy(collision.gameObject); // Destroy the bullet
            Destroy(gameObject); // Destroy the enemy
        }
    }
}
