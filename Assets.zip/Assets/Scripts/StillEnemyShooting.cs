using UnityEngine;

public class EnemyShooting : MonoBehaviour
{
    public GameObject bulletPrefab;        // Player laser prefab to be used by enemy
    public Transform shootingPoint3;       // First shooting point (e.g., left minigun)
    public Transform shootingPoint4;       // Second shooting point (e.g., right minigun)
    public float shootingInterval = 1.0f;  // Time interval between shots
    public float bulletSpeed = 5f;         // Speed of the bullet

    void Start()
    {
        // Start shooting bullets from both points at the specified interval
        InvokeRepeating(nameof(Shoot), 0f, shootingInterval);
    }

    void Shoot()
    {
        // Check if the bullet prefab and shooting points are assigned
        if (bulletPrefab != null)
        {
            // Instantiate bullets at both shooting points
            if (shootingPoint3 != null)
            {
                ShootFromPoint(shootingPoint3);
            }

            if (shootingPoint4 != null)
            {
                ShootFromPoint(shootingPoint4);
            }
        }
    }

    void ShootFromPoint(Transform shootingPoint)
    {
        // Instantiate the bullet at the shooting point
        GameObject bullet = Instantiate(bulletPrefab, shootingPoint.position, shootingPoint.rotation);

        // Get the Rigidbody2D component of the bullet to apply velocity
        Rigidbody2D bulletRb = bullet.GetComponent<Rigidbody2D>();
        if (bulletRb != null)
        {
            bulletRb.velocity = Vector2.down * bulletSpeed; // Move the bullet downward
        }
    }
}
